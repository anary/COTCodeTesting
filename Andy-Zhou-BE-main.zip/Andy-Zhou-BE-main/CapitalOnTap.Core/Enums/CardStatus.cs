﻿namespace CapitalOnTap.Core.Enums
{
    public enum CardStatus
    {
        Active,
        Frozen
    }
}
