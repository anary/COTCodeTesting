using System;
using SQLite;

namespace CapitalOnTap.Public.Api.Database.Entities
{
    [Table("Customer")]
    public class Customer
    {
        [PrimaryKey, AutoIncrement]
        [Column("Id")]
        public int Id { get; set; }

        [Column("FirstName")]
        public string FirstName { get; set; }

        [Column("LastName")]
        public string LastName { get; set; }

        [Column("CompanyName")]
        public string CompanyName { get; set; }

        [Column("PostCode")]
        public string PostCode { get; set; }

        [Column("Turnover")]
        public int AnnualTurnover { get; set; }

        [Column("MobileNumber")]
        public string MobileNumber { get; set; }

        [Column("CreatedAt")]
        public DateTime CreatedAt { get; set; }

        [Column("UpdatedAt")]
        public DateTime UpdatedAt { get; set; }
        
    }
}
