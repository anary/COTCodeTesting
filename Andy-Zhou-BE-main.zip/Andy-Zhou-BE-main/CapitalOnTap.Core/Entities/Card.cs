﻿using System;
using CapitalOnTap.Core.Enums;
using SQLite;
using ColumnAttribute = SQLite.ColumnAttribute;

namespace CapitalOnTap.Public.Api.Database.Entities
{
    [Table("Card")]
    public class Card
    {
        [PrimaryKey, AutoIncrement]
        [Column("Id")]
        public int Id { get; set; }

        [Column("FullName")]
        public string FullName { get; set; }

        [Column("CompanyName")]
        public string CompanyName { get; set; }

        [Column("CardNumber")]
        public string CardNumber { get; set; }

        [Column("ExpiryDate")]
        public DateTime ExpiryDate { get; set; }

        [Column("Status")]
        public CardStatus Status { get; set; }

        [Column("CustomerId")]
        public int CustomerId { get; set; }
    }
}