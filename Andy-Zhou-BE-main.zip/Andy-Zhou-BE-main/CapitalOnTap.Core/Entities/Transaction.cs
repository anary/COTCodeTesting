﻿using System;
using System.ComponentModel.DataAnnotations.Schema;
using SQLite;

namespace CapitalOnTap.Public.Api.Database.Entities
{
    public class Transaction
    {
        [PrimaryKey, AutoIncrement]
        [SQLite.Column("Id")]
        public int Id { get; set; }

        [SQLite.Column("Amount")]
        public double Amount { get; set; }

        [SQLite.Column("MerchantName")]
        public string MerchantName { get; set; }

        [SQLite.Column("PerformedAt")]
        public DateTime PerformedAt { get; set; }

        [SQLite.Column("Category")]
        public string Category { get; set; }

        [SQLite.Column("CustomerId")]
        public int CustomerId { get; set; }
    }
}