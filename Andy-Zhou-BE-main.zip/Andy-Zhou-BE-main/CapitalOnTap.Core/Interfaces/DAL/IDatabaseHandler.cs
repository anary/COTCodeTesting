﻿using System.Collections.Generic;
using System.Threading.Tasks;
using CapitalOnTap.Core.Enums;
using CapitalOnTap.Public.Api.Database.Entities;

namespace CapitalOnTap.Public.Api.Database
{
    public interface IDatabaseHandler
    {
        Task<Customer> AddCustomerAsync(Customer customer);
        Task<Customer> UpdateCustomerAsync(Customer customer);
        Task<Customer> GetCustomerAsync(int id);
        Task<Card> AddCardAsync(Card card);
        Task<Card> GetCardByIdAsync(int id);

        Task<Card> UpdateCardStatusAsync(Card card, CardStatus status);
        Task<IEnumerable<Transaction>> GetTransactions(int customerId);
    }
}