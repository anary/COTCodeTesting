﻿using System.Collections.Generic;
using System.Linq;
using SQLite;
using System.Threading.Tasks;
using CapitalOnTap.Public.Api.Database.Entities;
using CapitalOnTap.Core.Enums;
using System;

namespace CapitalOnTap.Public.Api.Database
{
    public class DatabaseHandler : IDatabaseHandler
    {

        private SQLiteAsyncConnection _db;

        public DatabaseHandler()
        {

            _db = new SQLiteAsyncConnection("./CapitalOnTap.db", SQLiteOpenFlags.Create |
                                                            SQLiteOpenFlags.FullMutex |
                                                            SQLiteOpenFlags.ReadWrite);
            _db.CreateTableAsync<Customer>();
            _db.CreateTableAsync<Card>();
        }

        public async Task<Customer> AddCustomerAsync(Customer customer)
        {
            await _db.InsertAsync(customer);
            return customer;
        }

        public async Task<Customer> UpdateCustomerAsync(Customer customer)
        {
            await _db.UpdateAsync(customer);
            return customer;
        }

        public async Task<Customer> GetCustomerAsync(int id)
        {
            var records = await _db.Table<Customer>().ToListAsync();
            return await _db.GetAsync<Customer>(x => x.Id == id);
        }

        public async Task<Card> AddCardAsync(Card card)
        {
            await _db.InsertAsync(card);
            return card;
        }

        public async Task<Card> GetCardByIdAsync(int id)
        {
            var records = await _db.Table<Card>().ToListAsync();
            return await _db.GetAsync<Card>(x => x.Id == id);
        }

        public async Task<Card> UpdateCardStatusAsync(Card card, CardStatus status)
        {
            if (card == null)
            {
                throw new ArgumentNullException(nameof(card));
            }

            card.Status = status;
            await _db.UpdateAsync(card);
            return card;
        }

        public async Task<IEnumerable<Transaction>> GetTransactions(int customerId)
        {
            var transactions = await _db.Table<Transaction>().ToListAsync();
            return transactions.Where(x => x.CustomerId == customerId);
        }
    }
}
