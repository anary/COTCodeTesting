﻿using System;

namespace CapitalOnTap.Business
{
    public class Class1
    {
    }
}
