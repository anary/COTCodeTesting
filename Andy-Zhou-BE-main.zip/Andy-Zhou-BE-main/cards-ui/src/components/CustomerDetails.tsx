import React, { useEffect, useState } from 'react';
import { Card } from 'antd';
import styled from 'styled-components';
import { useParams } from 'react-router-dom';
import { Customer } from '../types';
import { baseApiUrl } from '../config';

const Wrapper = styled.div`
  padding-top: 250px;
`;

const Container = styled(Card)`
  margin-left: auto;
  margin-right: auto;
  width: 500px;
`;

const Label = styled.div`
  font-size: 10px;
  font-weight: bold;
`;

const CustomerDetails = () => {
  const { id } = useParams<{id: string}>();
  const [customer, setCustomer] = useState<Customer>();

  useEffect(() => {
    const getData = async () => {
      const response = await fetch(`${baseApiUrl}/Customer/${id}`);

      if (!response.ok) {
        throw new Error(response.statusText);
      }

      setCustomer((await response.json()) as Customer);
    }
    
    getData();
  }, [id]) 

  return (
    <Wrapper>
      <Container title="Customer Details">
        <Label>First Name</Label>
        <p>{customer?.firstName}</p>
        <Label>Last Name</Label>
        <p>{customer?.lastName}</p>
        <Label>Company Name</Label>
        <p>{customer?.companyName}</p>
        <Label>Annual Turnover</Label>
        <p>£{customer?.annualTurnover}</p>
      </Container>
    </Wrapper>
  );
}

export default CustomerDetails;
