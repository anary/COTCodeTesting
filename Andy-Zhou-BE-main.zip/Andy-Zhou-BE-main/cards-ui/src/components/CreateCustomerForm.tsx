import React, { useState } from 'react';
import {
    Form,
    Input,
    InputNumber,
    Card,
    Button,
  } from 'antd';
import styled from 'styled-components';
import { Customer } from '../types';
import { baseApiUrl } from '../config';

const Wrapper = styled.div`
  padding-top: 250px;
`;

const Container = styled(Card)`
  margin-left: auto;
  margin-right: auto;
  width: 500px;
`;

const CreateCustomerForm = () => {
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async (customer: Customer) => {
    setSubmitting(true);

    const response = await fetch(`${baseApiUrl}/Customer`, 
    {
      method: 'POST',
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify(customer)
    });
  
    if (!response.ok) {
      throw new Error(response.statusText);
    }

    window.location.href = `/customer/${((await response.json()) as Customer).id}`;
  }

  return (
    <Wrapper>
      <Container title="Join Us!">
        <Form onFinish={handleSubmit} layout="vertical">
          <Form.Item name="firstName" label="First Name">
            <Input />
          </Form.Item>
          <Form.Item name="lastName" label="Last Name">
            <Input />
          </Form.Item>
          <Form.Item name="companyName" label="Company Name">
            <Input />
          </Form.Item>
          <Form.Item name="annualTurnover" label="Annual Turnover">
            <InputNumber style={{width: '100%'}} />
          </Form.Item>
          <Button htmlType="submit" loading={submitting}>
            Submit
          </Button>
        </Form>
      </Container>
    </Wrapper>
  );
}

export default CreateCustomerForm;
