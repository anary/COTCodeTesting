export interface Customer {
  id?: number;
  firstName: string;
  lastName: string;
  companyName: string;
  annualTurnover: number;
}

export interface Card {

}