import React from 'react';
import { BrowserRouter, Switch, Route } from 'react-router-dom';
import 'antd/dist/antd.css';

import CreateCustomerForm from './components/CreateCustomerForm';
import CustomerDetails from './components/CustomerDetails';

function App() {
  return (
    <BrowserRouter>
      <Switch>
        <Route path="/customer/:id">
          <CustomerDetails />
        </Route>
        <Route path="/">
          <CreateCustomerForm />
        </Route>
      </Switch>
    </BrowserRouter>
  );
}

export default App;
