﻿using System;
using System.Collections.Generic;
using System.Linq;
using CapitalOnTap.Public.Api.Database;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Threading.Tasks;
using CapitalOnTap.Public.Api.Contracts;
using CapitalOnTap.Public.Api.Database.Entities;
using CapitalOnTap.Public.Api.models;
using AutoMapper;
using Microsoft.AspNetCore.Http;
using CapitalOnTap.Core.Enums;

namespace CapitalOnTap.Public.Api.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class CustomerController : ControllerBase
    {
        private readonly ILogger<CustomerController> _logger;
        private readonly IDatabaseHandler _databaseHandler;
        private readonly IMapper _mapper;

        public CustomerController(ILogger<CustomerController> logger, IDatabaseHandler databaseHandler, IMapper mapper)
        {
            _logger = logger;
            _databaseHandler = databaseHandler;
            _mapper = mapper;
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<Customer>> Get(int id)
        {
            var customer = await _databaseHandler.GetCustomerAsync(id);
            return customer;
        }

        //[HttpPost]
        //public async Task<ActionResult<Customer>> Post(CustomerRequest customer)
        //{
        //    var insertedCustomer = await _databaseHandler.AddCustomerAsync(new Customer()
        //    {
        //        AnnualTurnover = customer.AnnualTurnover,
        //        CompanyName = customer.CompanyName,
        //        FirstName = customer.FirstName,
        //        LastName = customer.LastName,
        //        MobileNumber = customer.MobileNumber,
        //        PostCode = customer.PostCode,
        //        CreatedAt = DateTime.Now
        //    });

        //    // This is a pretend card generation/issuance
        //    var card = await _databaseHandler.AddCardAsync(new Card()
        //    {
        //        CardNumber = new string(DateTime.UtcNow.Ticks.ToString().Reverse().Take(16).ToArray()), //(Ticks returns 16 digit unique number which we will use a fake card number for the purposes of the test)
        //        ExpiryDate = DateTime.UtcNow.AddYears(5),
        //        FullName = $"{customer.FirstName} {customer.LastName}",
        //        CompanyName = customer.CompanyName,
        //        CustomerId = insertedCustomer.Id
        //    });

        //    return insertedCustomer;
        //}

        [HttpPost]
        public async Task<ActionResult<CustomerWithCardDto>> Post(CustomerForCreationDto customer)
        {
            var customerEntity = _mapper.Map<Customer>(customer);
            var insertedCustomer = await _databaseHandler.AddCustomerAsync(customerEntity);

            if (insertedCustomer == null)
            {
                return StatusCode(StatusCodes.Status500InternalServerError);
            }
            var cardEntity = _mapper.Map<Card>(insertedCustomer);
            var card = await _databaseHandler.AddCardAsync(cardEntity);

            if (card == null)
            {
                return StatusCode(StatusCodes.Status500InternalServerError);
            }

            var customerDto = _mapper.Map<CustomerWithCardDto>(cardEntity);
            customerDto.Id = insertedCustomer.Id;

            return customerDto;
        }

        [HttpPut("{id}")]
        public async Task<ActionResult<CustomerDto>> Put(int id, CustomerForUpdateDto customer)
        {
            var customerEntity = _databaseHandler.GetCustomerAsync(id);

            if (customerEntity == null)
            {
                return NotFound();
            }

            var Customer = _mapper.Map<Customer>(customer);
            Customer.Id = id;
            var updatedCustomer = await _databaseHandler.UpdateCustomerAsync(Customer);

            var customerDto = _mapper.Map<CustomerDto>(updatedCustomer);

            return customerDto;
        }

        [HttpPost("{cardId}")]
        public async Task<ActionResult> UpdateCardStatus(int cardId, CardStatus status)
        {
            var cardEntity = await _databaseHandler.GetCardByIdAsync(cardId);
            if (cardEntity == null)
            {
                return NotFound();
            }

            await _databaseHandler.UpdateCardStatusAsync(cardEntity, status);

            return NoContent();
        }


        [HttpGet("{customerId}/Transactions")]
        public async Task<ActionResult<IEnumerable<Transaction>>> GetTransactions(int customerId)
        {
            var transactions = await _databaseHandler.GetTransactions(customerId);
            return Ok(transactions);
        }
    }
}
