﻿using AutoMapper;
using CapitalOnTap.Core.Enums;
using CapitalOnTap.Public.Api.Database.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapitalOnTap.Public.Api.Profiles
{
    public class CardProfile: Profile
    {
        public CardProfile()
        {
            CreateMap<Customer, Card>()
                .ForMember(
                    dest => dest.CardNumber,
                    opt => opt.MapFrom(src => new string(DateTime.UtcNow.Ticks.ToString().Reverse().Take(16).ToArray()))) //(Ticks returns 16 digit unique number which we will use a fake card number for the purposes of the test)
                .ForMember(
                        dest => dest.ExpiryDate,
                        opt => opt.MapFrom(src => DateTime.UtcNow.AddYears(5)))
                .ForMember(
                        dest => dest.FullName,
                        opt => opt.MapFrom(src => $"{src.FirstName} {src.LastName}"))
                .ForMember(
                        dest => dest.CustomerId,
                        opt => opt.MapFrom(src => src.Id))
                .ForMember(
                        dest => dest.Status,
                        // default card is Active
                        opt => opt.MapFrom(src => CardStatus.Active));
                
        }
    }
}
