﻿using AutoMapper;
using CapitalOnTap.Public.Api.Database.Entities;
using CapitalOnTap.Public.Api.models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapitalOnTap.Public.Api.Profiles
{
    public class CustomsProfile: Profile
    {
        public CustomsProfile()
        {
            CreateMap<CustomerForCreationDto, Customer>()
                .ForMember(
                    dest => dest.CreatedAt,
                    opt => opt.MapFrom(src => DateTime.Now)
                );

            CreateMap<CustomerWithCardDto, Card>();
              
        }
    }
}
