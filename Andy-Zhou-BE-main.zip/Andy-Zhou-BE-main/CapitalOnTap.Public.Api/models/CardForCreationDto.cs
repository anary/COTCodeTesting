﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapitalOnTap.Public.Api.models
{
    public class CardForCreationDto
    {
        public string FullName { get; set; }

        public string CompanyName { get; set; }

        public string CardNumber { get; set; }

        public DateTime ExpiryDate { get; set; }
    }
}
