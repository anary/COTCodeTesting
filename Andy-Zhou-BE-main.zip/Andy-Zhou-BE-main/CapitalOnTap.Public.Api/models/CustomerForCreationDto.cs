﻿using CapitalOnTap.Core.Enums;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace CapitalOnTap.Public.Api.models
{
    // The model should have validation rules on it. I will not add on this stage, as it is not on the requirement
    public class CustomerForCreationDto
    {
        public string FirstName { get; set; }

        public string LastName { get; set; }

        public string CompanyName { get; set; }

        public string PostCode { get; set; }

        public int AnnualTurnover { get; set; }

        public string MobileNumber { get; set; }

        public DateTime CreatedAt { get; set; }

        public DateTime UpdatedAt { get; set; }
    }
}
