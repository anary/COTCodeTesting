﻿using CapitalOnTap.Core.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapitalOnTap.Public.Api.models
{
    public class CustomerWithCardDto
    {
        public int Id { get; set; }

        public string FullName { get; set; }

        public string CompanyName { get; set; }

        public string CardNumber { get; set; }

        public DateTime ExpiryDate { get; set; }

        public CardStatus Status { get; set; }
    }
}
