﻿using System;

namespace CapitalOnTap.Public.Api.models
{
    public class CustomerForUpdateDto
    {
        public string FirstName { get; set; }

        public string LastName { get; set; }

        public string CompanyName { get; set; }

        public string PostCode { get; set; }

        public int AnnualTurnover { get; set; }

        public string MobileNumber { get; set; }
    }
}
