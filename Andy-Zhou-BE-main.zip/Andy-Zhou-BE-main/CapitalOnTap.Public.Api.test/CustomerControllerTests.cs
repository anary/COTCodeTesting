using AutoMapper;
using CapitalOnTap.Core.Enums;
using CapitalOnTap.Public.Api.Controllers;
using CapitalOnTap.Public.Api.Database;
using CapitalOnTap.Public.Api.Database.Entities;
using CapitalOnTap.Public.Api.models;
using Castle.Core.Logging;
using Microsoft.AspNetCore.Mvc;
using Moq;
using NUnit.Framework;
using System.Threading.Tasks;

namespace CapitalOnTap.Public.Api.test
{
    public class CustomerControllerTests
    {
        const int ID = 10;
        private CustomerController _sut;
        private Mock<IDatabaseHandler> _databaseHandlerMock;
        private Mock<IMapper> _mapperMock;
        private Mock<ILogger> _loggerMock;

        [SetUp]
        public void Setup()
        {
            _databaseHandlerMock = new Mock<IDatabaseHandler>();
            _mapperMock = new Mock<IMapper>();
            _loggerMock = new Mock<ILogger>();
        }

        [Test]
        public async void Post_ShouldReturnCustomerDto_OnCustomerParamter()
        {
            // Arrange
            var customer = new Customer() { Id = ID};
            _mapperMock.Setup(m => m.Map<Customer>(It.IsAny<CustomerForCreationDto>())).Returns(customer);
            _databaseHandlerMock.Setup(d => d.AddCustomerAsync(customer)).Returns(Task.FromResult(customer));
            var card = new Card();
            _mapperMock.Setup(m => m.Map<Card>(customer)).Returns(card);
            _databaseHandlerMock.Setup(d => d.AddCardAsync(card)).Returns(Task.FromResult(card));

            var customerDto = new CustomerWithCardDto() { Id = ID };
            
            _mapperMock.Setup(m => m.Map<CustomerWithCardDto>(card)).Returns(customerDto);
            
            // Act
            var result = await _sut.Post(new CustomerForCreationDto());
            
            // Assert
            Assert.AreEqual(customerDto, result.Value);
        }

        [Test]
        public async void Post_ShouldReturn500InternalError_WhenInsertCustomerError()
        {
            // Arrange
            // Mock the _databaseHandler.AddCustomerAsync Error

            // Act
            var result = await _sut.Post(new CustomerForCreationDto());

            // Assert
            // Assert return value be StatusCodes.Status500InternalServerError
        }

        [Test]
        public async void Post_ShouldReturn500InternalError_WhenAddCardError()
        {
            // Arrange
            // Mock the _databaseHandler.AddCardAsync Error

            // Act
            var result = await _sut.Post(new CustomerForCreationDto());

            // Assert
            // Assert return value be StatusCodes.Status500InternalServerError
        }


        [Test]
        public async void UpdateCardStatus_ShouldReturnNotCotent_WhenCardIdExistsInDB()
        {
            // Arrange
            // Mock All injected Services
            const int CARD_ID = 1;
            const CardStatus status = CardStatus.Active;

            // Act
            var result = await _sut.UpdateCardStatus(CARD_ID, status);

            // Assert
            Assert.IsInstanceOf<NoContentResult>(result);
        }

        [Test]
        public async void UpdateCardStatus_ShouldCallUpdateCardStatusAsync_WhenCardExists()
        {
            // Arrange
            // Mock All injected Services
            const int CARD_ID = 1;
            var card = new Card();

            const CardStatus status = CardStatus.Active;

            // Act
            var result = await _sut.UpdateCardStatus(CARD_ID, status);

            // Assert
            _databaseHandlerMock.Verify(d => d.UpdateCardStatusAsync(card, status), Times.Once);
        }

        [Test]
        public async void UpdateCardStatus_ShouldReturnNotFound_WhenCardIdNotExist()
        {
            // Arrange
            // Mock All injected Services
            const int CARD_ID = 1;
            const CardStatus status = CardStatus.Active;
            //Mock _databaseHandler.GetCardByIdAsync return null

            // Act
            var result = await _sut.UpdateCardStatus(CARD_ID, status);

            // Assert
            Assert.IsInstanceOf<NotFoundResult>(result);
        }
    }
}